package seleniumro.core;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public abstract class BaseTest {

	protected WebDriver driver;
	
	@BeforeClass
	public void setup(){
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://testing.webtic.info/wordpress/wp-login.php");
	}
	
	@AfterClass
	public void close(){
		driver.close();
	}
	
}

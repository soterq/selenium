package seleniumro.poms;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.htmlelements.element.TextBlock;
import ru.yandex.qatools.htmlelements.element.TextInput;
import seleniumro.core.AbstractPOM;

public class AddNewPost extends AbstractPOM{
	
	public AddNewPost(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(xpath = "//div[@class='wrap']/h1")
	public TextBlock pageNameLabel;
	
	@FindBy(xpath = "//input[@name='post_title']")
	public TextInput postTitleInput;
}

package seleniumro.poms;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.htmlelements.element.Button;
import ru.yandex.qatools.htmlelements.element.TextBlock;
import ru.yandex.qatools.htmlelements.element.TextInput;
import seleniumro.core.AbstractPOM;

public class LoginPage extends AbstractPOM{

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//input[@id='user_login']")
	public TextInput userNameInput;
	
	@FindBy(id = "user_pass")
	public TextInput userPassInput;
	
	@FindBy(id = "wp-submit")
	public Button submitBtn;
	
	@FindBy(xpath = "//div[@id='login_error']")
	public TextBlock errorMsg;
	
	public void login(String strUserName, String strPasword) {
		userNameInput.sendKeys(strUserName);
		userPassInput.sendKeys(strPasword);
		submitBtn.click();
	}
}
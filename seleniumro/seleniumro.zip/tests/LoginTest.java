package seleniumro.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import seleniumro.core.BaseTest;
import seleniumro.poms.DashboardPage;
import seleniumro.poms.LoginPage;

@Test
public class LoginTest extends BaseTest {
	
	public void test(){
		LoginPage lp = new LoginPage(driver);
		lp.login("admin", "admin_pass!");
		
		DashboardPage dp = new DashboardPage(driver);
		Assert.assertTrue(dp.pageTitle.isDisplayed(), "Page title for Dashboard page is displayed");
		Assert.assertEquals(dp.pageTitle.getText(), "Dashboard", "Validate page title");
		
		Assert.assertTrue(dp.welcomeMsg.isDisplayed(), "Welcome msg is displayed");
		Assert.assertEquals(dp.welcomeMsg.getText(), "Welcome to WordPress!", "Validate welcome msg");
	}
}

package seleniumro.tests;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import seleniumro.core.BaseTest;
import seleniumro.poms.DashboardPage;
import seleniumro.poms.LoginPage;



public class TestAutoQALogin extends BaseTest{

	
	
////	@Test
//	public void testPostsPage() throws InterruptedException{
//		objLogin = new LoginPage(driver);
//		objLogin.login("admin", "admin_pass!");
//		objHomePage = new DashboardPage(driver);
//		LeftMenu lm = new LeftMenu(driver);
//		WebDriverWait wait = new WebDriverWait(driver, 20);
//		
//		Actions action = new Actions(driver);
////		action.pause(Duration.ofSeconds(2)).moveToElement(lm.postsLnk).pause(Duration.ofSeconds(2)).moveToElement(lm.allPostsLnk).pause(Duration.ofSeconds(1)).click().build().perform();
//		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='adminmenuwrap']/ul/li/a[./div[contains(text(),'Posts')]]")));
//		action.moveToElement(lm.postsLnk).build().perform();
//		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='adminmenuwrap']/ul/li[./a/div[contains(text(),'Posts')]]/ul/li/a[text()='All Posts']")));
//		action.moveToElement(lm.allPostsLnk).click().build().perform();
//		
//		PostsPage pp = new PostsPage(driver);
////		WebDriverWait wait = new WebDriverWait(driver, 20);
//		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='wrap']/h1")));
//		
//		Assert.assertTrue(pp.pageName.getText().toLowerCase().contains("posts"), "Page name:'" + pp.pageName.getText() + "'");
//	}

}

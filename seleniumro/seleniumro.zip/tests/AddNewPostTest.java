package seleniumro.tests;

import static seleniumro.core.Helpers.check2StringIfEquals;

import org.testng.Assert;
import org.testng.annotations.Test;

import seleniumro.core.BaseTest;
import seleniumro.poms.AddNewPost;
import seleniumro.poms.DashboardPage;
import seleniumro.poms.LeftMenu;
import seleniumro.poms.LoginPage;
import seleniumro.poms.Posts;

@Test
public class AddNewPostTest extends BaseTest {
	
	public void test() throws InterruptedException {
		LoginPage lp = new LoginPage(driver);
		lp.login("admin", "admin_pass!");
		
		DashboardPage dp = new DashboardPage(driver);
		Assert.assertTrue(dp.pageTitle.isDisplayed(), "Page title for Dashboard page is displayed");
		
		LeftMenu lm = new LeftMenu(driver);
//		Helpers.click(driver, lm.postsLnk, lm.addNewPostLnk);
//		
//		Thread.sleep(5000);
//		
//		AddNewPost anp = new AddNewPost(driver);
//		Assert.assertTrue(anp.pageNameLabel.isDisplayed(), "Page label is displayed for Add New post page");
//		check2StringIfEquals(anp.pageNameLabel, "Add a New Post");
		
		lm.postsLnk.click();
		
		Posts posts = new Posts(driver);
		Assert.assertTrue(posts.pageNameLabel.isDisplayed(), "Page title for Posts page is displayed");
		lm.addNewPostNotHoverLnk.click();
		
		AddNewPost anp = new AddNewPost(driver);
		Assert.assertTrue(anp.pageNameLabel.isDisplayed(), "Page label is displayed for Add New post page");
		check2StringIfEquals(anp.pageNameLabel, "Add a New Post");
		anp.postTitleInput.sendKeys("My new post");
		
		Thread.sleep(5000);
	}
}
